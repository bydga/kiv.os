/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.zcu.kiv.os.core.interrupts;

/**
 *
 * @author bydga
 */
public enum KeyboardEvent {
	
	ARROW_UP,
	
	ARROW_DOWN
	
}
